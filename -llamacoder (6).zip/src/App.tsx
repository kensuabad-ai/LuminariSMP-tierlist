import { useState, useEffect } from 'react';
import { Shield, Trophy, Menu, X } from 'lucide-react';
import { Player, Match, PointRules, Report, AuditLog } from './types';
import { storage } from './utils/storage';
import { mockData } from './utils/mockData';
import { getTierByRating } from './utils/tierSystem';
import { Header } from './components/Header';
import { Leaderboard } from './components/Leaderboard';
import { PlayerProfile } from './components/PlayerProfile';
import { MatchReportModal } from './components/MatchReportModal';
import { AdminPanel } from './components/AdminPanel';
import { Button } from './components/ui/button';
import { Input } from './components/ui/input';
import { Card, CardContent } from './components/ui/card';

function App() {
  const [players, setPlayers] = useState<Player[]>([]);
  const [matches, setMatches] = useState<Match[]>([]);
  const [pointRules, setPointRules] = useState<PointRules>(mockData.pointRules);
  const [reports, setReports] = useState<Report[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
  const [showReportModal, setShowReportModal] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [activeTab, setActiveTab] = useState<'leaderboard' | 'admin'>('leaderboard');

  useEffect(() => {
    const savedState = storage.load();
    if (savedState) {
      setPlayers(savedState.players);
      setMatches(savedState.matches);
      setPointRules(savedState.pointRules);
      setReports(savedState.reports || []);
      setAuditLogs(savedState.auditLogs || []);
    } else {
      setPlayers(mockData.players);
      setMatches(mockData.matches);
      setReports(mockData.reports || []);
      setAuditLogs(mockData.auditLogs || []);
    }
  }, []);

  useEffect(() => {
    storage.save({
      players,
      matches,
      pointRules,
      reports,
      auditLogs
    });
  }, [players, matches, pointRules, reports, auditLogs]);

  const addAuditLog = (action: string) => {
    const newLog: AuditLog = {
      id: Date.now().toString(),
      action,
      timestamp: new Date().toISOString(),
      admin: 'Admin'
    };
    setAuditLogs(prev => [newLog, ...prev]);
  };

  const handleAdminLogin = () => {
    if (adminPassword === 'Kensu.com2') {
      setIsAdmin(true);
      setShowAdminLogin(false);
      setAdminPassword('');
      setActiveTab('admin');
    } else {
      alert('Incorrect password');
    }
  };

  const handleRecordMatch = (matchData: any) => {
    const winner = players.find(p => p.id === matchData.winnerId);
    const loser = players.find(p => p.id === matchData.loserId);
    
    if (!winner || !loser) return;

    const newMatch: Match = {
      id: Date.now().toString(),
      winnerId: matchData.winnerId,
      loserId: matchData.loserId,
      mode: matchData.mode,
      resultType: matchData.resultType,
      date: new Date().toISOString().split('T')[0],
      winnerRating: matchData.winnerNewRating,
      loserRating: matchData.loserNewRating,
      winnerPoints: matchData.winnerPoints,
      loserPoints: matchData.loserPoints
    };

    setMatches(prev => [newMatch, ...prev]);
    
    setPlayers(prev => prev.map(p => {
      if (p.id === matchData.winnerId) {
        return {
          ...p,
          rating: matchData.winnerNewRating,
          wins: p.wins + 1,
          tier: getTierByRating(matchData.winnerNewRating).name,
          tierGroup: getTierByRating(matchData.winnerNewRating).group,
          tierLevel: getTierByRating(matchData.winnerNewRating).level,
          title: getTierByRating(matchData.winnerNewRating).title,
          modeStats: {
            ...p.modeStats,
            [matchData.mode]: {
              wins: p.modeStats[matchData.mode].wins + 1,
              losses: p.modeStats[matchData.mode].losses
            }
          }
        };
      }
      if (p.id === matchData.loserId) {
        return {
          ...p,
          rating: matchData.loserNewRating,
          losses: p.losses + 1,
          tier: getTierByRating(matchData.loserNewRating).name,
          tierGroup: getTierByRating(matchData.loserNewRating).group,
          tierLevel: getTierByRating(matchData.loserNewRating).level,
          title: getTierByRating(matchData.loserNewRating).title,
          modeStats: {
            ...p.modeStats,
            [matchData.mode]: {
              wins: p.modeStats[matchData.mode].wins,
              losses: p.modeStats[matchData.mode].losses + 1
            }
          }
        };
      }
      return p;
    }));

    addAuditLog(`Match recorded: ${winner.ign} beat ${loser.ign} (${matchData.mode})`);
  };

  const handleEditPlayer = (playerId: string, updates: Partial<Player>) => {
    setPlayers(prev => prev.map(p => {
      if (p.id === playerId) {
        return { ...p, ...updates };
      }
      return p;
    }));
    addAuditLog(`Player ${playerId} stats updated`);
  };

  const handleRemovePlayer = (playerId: string) => {
    const player = players.find(p => p.id === playerId);
    setPlayers(prev => prev.filter(p => p.id !== playerId));
    if (player) {
      addAuditLog(`Player ${player.ign} removed from leaderboard`);
    }
  };

  const handleAddPlayer = (ign: string, rating: number) => {
    const tier = getTierByRating(rating);
    const newPlayer: Player = {
      id: Date.now().toString(),
      ign,
      rating,
      wins: 0,
      losses: 0,
      tier: tier.name,
      tierGroup: tier.group,
      tierLevel: tier.level,
      title: tier.title,
      modeStats: {
        axe: { wins: 0, losses: 0 },
        nethpot: { wins: 0, losses: 0 },
        smp: { wins: 0, losses: 0 },
        mace: { wins: 0, losses: 0 }
      }
    };
    
    setPlayers(prev => [...prev, newPlayer]);
    addAuditLog(`Player ${ign} added to leaderboard at ${rating} rating (${tier.name})`);
  };

  const handleUpdateRules = (newRules: PointRules) => {
    setPointRules(newRules);
    addAuditLog('Point rules updated');
  };

  const handleReportMatch = (report: Omit<Report, 'id' | 'timestamp' | 'status'>) => {
    const newReport: Report = {
      ...report,
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      status: 'pending'
    };
    setReports(prev => [newReport, ...prev]);
    setShowReportModal(false);
    alert('Match reported successfully');
  };

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100">
      <Header 
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onAdminClick={() => isAdmin ? setActiveTab('admin') : setShowAdminLogin(true)}
        isAdmin={isAdmin}
      />

      <main className="container mx-auto px-4 py-8">
        {activeTab === 'leaderboard' && (
          <Leaderboard 
            players={players}
            matches={matches}
            onPlayerClick={setSelectedPlayer}
          />
        )}

        {activeTab === 'admin' && isAdmin && (
          <AdminPanel
            pointRules={pointRules}
            players={players}
            matches={matches}
            auditLogs={auditLogs}
            onUpdateRules={handleUpdateRules}
            onRecordMatch={handleRecordMatch}
            onEditMatch={() => {}}
            onEditPlayer={handleEditPlayer}
            onRemovePlayer={handleRemovePlayer}
            onAddPlayer={handleAddPlayer}
          />
        )}
      </main>

      {/* Player Profile Modal */}
      {selectedPlayer && (
        <PlayerProfile
          player={selectedPlayer}
          matches={matches}
          allPlayers={players}
          onClose={() => setSelectedPlayer(null)}
          onReportMatch={() => setShowReportModal(true)}
        />
      )}

      {/* Match Report Modal */}
      {showReportModal && (
        <MatchReportModal
          onClose={() => setShowReportModal(false)}
          onSubmit={handleReportMatch}
        />
      )}

      {/* Admin Login Modal */}
      {showAdminLogin && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <Card className="w-full max-w-md bg-gray-800 border-gray-700">
            <CardContent className="p-6 space-y-4">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-amber-500/20 rounded-lg flex items-center justify-center">
                  <Shield className="w-5 h-5 text-amber-500" />
                </div>
                <h2 className="text-xl font-bold text-white">Admin Access</h2>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Password</label>
                <Input
                  type="password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAdminLogin()}
                  placeholder="Enter admin password..."
                  className="bg-gray-900 border-gray-700 text-white"
                />
              </div>
              
              <div className="flex gap-2 pt-2">
                <Button 
                  onClick={handleAdminLogin}
                  className="flex-1 bg-amber-500 hover:bg-amber-600 text-amber-950"
                >
                  Access Admin Panel
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => {
                    setShowAdminLogin(false);
                    setAdminPassword('');
                  }}
                  className="flex-1 border-gray-700 text-gray-300"
                >
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}

export default App;