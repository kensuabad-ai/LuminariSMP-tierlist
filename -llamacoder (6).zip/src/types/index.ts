export interface Player {
  id: string;
  ign: string;
  tier: string;
  tierGroup: 'Low' | 'High';
  tierLevel: number;
  title: string;
  rating: number;
  wins: number;
  losses: number;
  modeStats: {
    axe: { wins: number; losses: number };
    nethpot: { wins: number; losses: number };
    smp: { wins: number; losses: number };
    mace: { wins: number; losses: number };
  };
}

export interface Match {
  id: string;
  date: string;
  winnerId: string;
  loserId: string;
  mode: 'axe' | 'nethpot' | 'smp' | 'mace';
  resultType: 'dominant' | 'clean' | 'close';
  winnerRating: number;
  loserRating: number;
  winnerPoints: number;
  loserPoints: number;
}

export interface Report {
  id: string;
  matchId: string;
  reason: string;
  description: string;
  screenshot: string | null;
  status: 'pending' | 'reviewed' | 'resolved';
  timestamp: string;
}

export interface AuditLog {
  id: string;
  action: string;
  timestamp: string;
  admin?: string;
}

export interface PointRules {
  axe: ModeRules;
  nethpot: ModeRules;
  smp: ModeRules;
  mace: ModeRules;
}

export interface ModeRules {
  dominant: number;
  clean: number;
  close: number;
  lossHigher: number;
  lossEqual: number;
  lossLower: number;
  lossMuchLower: number;
  dominantLossDown: number;
  tier1Bonus: number;
  tier2Bonus: number;
  lowerTierCap: number;
  maxCap: number;
  repeatMultiplier: number;
  gapMultiplier: number;
  maxGain: number;
  beatHigherBonus: number;
  beatLowerMax: number;
  antiFarmMult: number;
}

// Export alias to fix "ModePointRules" missing export error
export type ModePointRules = ModeRules;