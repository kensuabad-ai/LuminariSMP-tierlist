import { X, Flag, Calendar, User, TrendingUp, TrendingDown } from 'lucide-react';
import { Player, Match } from '../types';
import { TierBadge } from './TierBadge';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';

interface PlayerProfileProps {
  player: Player;
  matches: Match[];
  allPlayers: Player[];
  onClose: () => void;
  onReportMatch: () => void;
}

export const PlayerProfile = ({ player, matches, allPlayers, onClose, onReportMatch }: PlayerProfileProps) => {
  const getPlayerById = (id: string) => allPlayers.find(p => p.id === id);
  
  const playerMatches = matches
    .filter(m => m.winnerId === player.id || m.loserId === player.id)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5);
  
  const getWinRate = (wins: number, losses: number) => {
    const total = wins + losses;
    return total > 0 ? ((wins / total) * 100).toFixed(1) : '0.0';
  };
  
  const getTierProgress = (rating: number) => {
    if (rating >= 500) return 100;
    const nextThreshold = Math.ceil((rating + 1) / 50) * 50;
    const currentThreshold = nextThreshold - 50;
    return ((rating - currentThreshold) / 50) * 100;
  };
  
  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto bg-gray-800 border-gray-700">
        <CardHeader className="border-b border-gray-700">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
                {player.ign.slice(0, 2).toUpperCase()}
              </div>
              <div>
                <CardTitle className="text-2xl text-white">{player.ign}</CardTitle>
                <p className="text-gray-400">{player.title}</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-5 h-5 text-gray-400" />
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="p-6 space-y-6">
          {/* Stats Overview */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-gray-900 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-amber-400">{player.rating}</div>
              <div className="text-xs text-gray-400">Rating</div>
            </div>
            <div className="bg-gray-900 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-emerald-400">{player.wins}</div>
              <div className="text-xs text-gray-400">Wins</div>
            </div>
            <div className="bg-gray-900 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-red-400">{player.losses}</div>
              <div className="text-xs text-gray-400">Losses</div>
            </div>
            <div className="bg-gray-900 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-white">{getWinRate(player.wins, player.losses)}%</div>
              <div className="text-xs text-gray-400">Win Rate</div>
            </div>
          </div>
          
          {/* Tier Progress */}
          <div className="bg-gray-900 rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-300">Tier Progress</span>
              <span className="text-sm text-gray-400">{getTierProgress(player.rating).toFixed(0)}%</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full transition-all"
                style={{ width: `${getTierProgress(player.rating)}%` }}
              />
            </div>
            <div className="mt-2">
              <TierBadge rating={player.rating} />
            </div>
          </div>
          
          {/* Mode Stats */}
          <div>
            <h3 className="text-lg font-bold text-white mb-3">Mode Statistics</h3>
            <div className="bg-gray-900 rounded-lg overflow-hidden">
              <table className="w-full">
                <thead className="bg-gray-800">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Mode</th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Wins</th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Losses</th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Win Rate</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-800">
                  {Object.entries(player.modeStats).map(([mode, stats]) => (
                    <tr key={mode}>
                      <td className="px-4 py-3 text-sm text-white capitalize">{mode}</td>
                      <td className="px-4 py-3 text-sm text-emerald-400 text-right">{stats.wins}</td>
                      <td className="px-4 py-3 text-sm text-red-400 text-right">{stats.losses}</td>
                      <td className="px-4 py-3 text-sm text-gray-300 text-right">
                        {getWinRate(stats.wins, stats.losses)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          
          {/* Recent Matches */}
          <div>
            <h3 className="text-lg font-bold text-white mb-3">Recent Matches</h3>
            <div className="space-y-2">
              {playerMatches.length > 0 ? (
                playerMatches.map(match => {
                  const isWinner = match.winnerId === player.id;
                  const opponent = getPlayerById(isWinner ? match.loserId : match.winnerId);
                  return (
                    <div key={match.id} className="bg-gray-900 rounded-lg p-3 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                          isWinner ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                        }`}>
                          {isWinner ? 'W' : 'L'}
                        </div>
                        <div>
                          <div className="text-sm text-white">{opponent?.ign || 'Unknown'}</div>
                          <div className="text-xs text-gray-500 capitalize">{match.mode}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {isWinner ? (
                          <TrendingUp className="w-4 h-4 text-emerald-400" />
                        ) : (
                          <TrendingDown className="w-4 h-4 text-red-400" />
                        )}
                        <span className={`text-sm font-mono ${isWinner ? 'text-emerald-400' : 'text-red-400'}`}>
                          {isWinner ? '+' : ''}{isWinner ? match.winnerPoints : match.loserPoints}
                        </span>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-8 text-gray-500">
                  No recent matches
                </div>
              )}
            </div>
          </div>
          
          {/* Report Match Button */}
          <Button 
            onClick={onReportMatch}
            className="w-full bg-red-500 hover:bg-red-600 gap-2"
          >
            <Flag className="w-4 h-4" />
            Report Match Issue
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};