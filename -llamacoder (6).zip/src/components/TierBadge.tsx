import { getTierByRating } from '../utils/tierSystem';

interface TierBadgeProps {
  rating: number;
  compact?: boolean;
}

export const TierBadge = ({ rating, compact = false }: TierBadgeProps) => {
  const tier = getTierByRating(rating);
  
  if (compact) {
    return (
      <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold ${
        tier.group === 'High' 
          ? 'bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-400 border border-amber-500/20' 
          : 'bg-gradient-to-r from-blue-500/20 to-purple-500/20 text-blue-400 border border-blue-500/20'
      }`}>
        <span className="w-1.5 h-1.5 rounded-full bg-current" />
        {tier.name}
      </div>
    );
  }
  
  return (
    <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-bold ${
      tier.group === 'High' 
        ? 'bg-gradient-to-r from-amber-500/20 to-orange-500/20 text-amber-400 border border-amber-500/20' 
        : 'bg-gradient-to-r from-blue-500/20 to-purple-500/20 text-blue-400 border border-blue-500/20'
    }`}>
      <span className="w-2 h-2 rounded-full bg-current" />
      {tier.name}
    </div>
  );
};