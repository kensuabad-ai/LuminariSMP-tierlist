import { useState } from 'react';
import { Search, Trophy, Medal, Award } from 'lucide-react';
import { Player } from '../types';
import { TierBadge } from './TierBadge';
import { Input } from '../components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';

interface LeaderboardProps {
  players: Player[];
  onPlayerClick: (player: Player) => void;
}

type SortField = 'rank' | 'ign' | 'tier' | 'rating' | 'wins' | 'losses' | 'winRate';
type SortDirection = 'asc' | 'desc';

export const Leaderboard = ({ players, onPlayerClick }: LeaderboardProps) => {
  const [search, setSearch] = useState('');
  const [tierGroupFilter, setTierGroupFilter] = useState<'all' | 'Low' | 'High'>('all');
  const [tierLevelFilter, setTierLevelFilter] = useState<'all' | number>('all');
  const [sortField, setSortField] = useState<SortField>('rating');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  
  const getWinRate = (player: Player) => {
    const total = player.wins + player.losses;
    return total > 0 ? ((player.wins / total) * 100).toFixed(1) : '0.0';
  };
  
  const filteredPlayers = players
    .filter(p => p.ign.toLowerCase().includes(search.toLowerCase()))
    .filter(p => tierGroupFilter === 'all' || p.tierGroup === tierGroupFilter)
    .filter(p => tierLevelFilter === 'all' || p.tierLevel === tierLevelFilter)
    .sort((a, b) => {
      let comparison = 0;
      
      switch (sortField) {
        case 'rank':
          comparison = b.rating - a.rating;
          break;
        case 'ign':
          comparison = a.ign.localeCompare(b.ign);
          break;
        case 'tier':
          comparison = b.tierLevel - a.tierLevel;
          break;
        case 'rating':
          comparison = a.rating - b.rating;
          break;
        case 'wins':
          comparison = a.wins - b.wins;
          break;
        case 'losses':
          comparison = a.losses - b.losses;
          break;
        case 'winRate':
          comparison = parseFloat(getWinRate(a)) - parseFloat(getWinRate(b));
          break;
      }
      
      return sortDirection === 'asc' ? comparison : -comparison;
    });
  
  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };
  
  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Trophy className="w-5 h-5 text-amber-400" />;
    if (rank === 2) return <Medal className="w-5 h-5 text-gray-300" />;
    if (rank === 3) return <Award className="w-5 h-5 text-amber-600" />;
    return null;
  };
  
  const getRankStyle = (rank: number) => {
    if (rank === 1) return 'text-amber-400 font-bold';
    if (rank === 2) return 'text-gray-300 font-bold';
    if (rank === 3) return 'text-amber-600 font-bold';
    return 'text-gray-400';
  };

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex flex-col lg:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <Input
            placeholder="Search players..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-gray-900/50 border-gray-800 text-white placeholder:text-gray-600 focus:border-purple-500"
          />
        </div>
        <Select value={tierGroupFilter} onValueChange={(v: any) => setTierGroupFilter(v)}>
          <SelectTrigger className="w-full lg:w-40 bg-gray-900/50 border-gray-800 text-white focus:border-purple-500">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-gray-900 border-gray-800">
            <SelectItem value="all">All Tiers</SelectItem>
            <SelectItem value="Low">Low Tier</SelectItem>
            <SelectItem value="High">High Tier</SelectItem>
          </SelectContent>
        </Select>
        <Select value={tierLevelFilter.toString()} onValueChange={(v) => setTierLevelFilter(v === 'all' ? 'all' : parseInt(v))}>
          <SelectTrigger className="w-full lg:w-48 bg-gray-900/50 border-gray-800 text-white focus:border-purple-500">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-gray-900 border-gray-800">
            <SelectItem value="all">All Levels</SelectItem>
            {[...Array(10)].map((_, i) => {
              const level = 10 - i;
              const name = level <= 5 ? `Low Tier ${6 - level}` : `High Tier ${11 - level}`;
              return <SelectItem key={level} value={level.toString()}>{name}</SelectItem>;
            })}
          </SelectContent>
        </Select>
      </div>
      
      {/* Leaderboard Table */}
      <div className="bg-gray-900/50 backdrop-blur-sm rounded-xl border border-gray-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-950/50">
              <tr>
                {[
                  { field: 'rank', label: 'Rank' },
                  { field: 'ign', label: 'Player' },
                  { field: 'tier', label: 'Tier' },
                  { field: 'rating', label: 'Rating' },
                  { field: 'wins', label: 'Wins' },
                  { field: 'losses', label: 'Losses' },
                  { field: 'winRate', label: 'Win Rate' },
                ].map(({ field, label }) => (
                  <th
                    key={field}
                    className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase tracking-wider cursor-pointer hover:text-purple-400 transition-colors"
                    onClick={() => handleSort(field as SortField)}
                  >
                    <div className="flex items-center gap-2">
                      {label}
                      {sortField === field && (
                        <span className="text-purple-400">
                          {sortDirection === 'asc' ? '↑' : '↓'}
                        </span>
                      )}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800/50">
              {filteredPlayers.map((player, index) => (
                <tr
                  key={player.id}
                  className="hover:bg-gray-800/50 cursor-pointer transition-all group"
                  onClick={() => onPlayerClick(player)}
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      {getRankIcon(index + 1)}
                      <span className={`text-lg font-mono ${getRankStyle(index + 1)}`}>
                        #{index + 1}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm ${
                        player.tierGroup === 'High' 
                          ? 'bg-gradient-to-br from-amber-500 to-orange-600 shadow-lg shadow-amber-500/20' 
                          : 'bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg shadow-blue-500/20'
                      }`}>
                        {player.ign.slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="text-sm font-bold text-white group-hover:text-purple-400 transition-colors">{player.ign}</div>
                        <div className="text-xs text-gray-500">{player.title}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <TierBadge rating={player.rating} compact />
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-lg font-bold font-mono text-white">
                      {player.rating}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-emerald-400 font-semibold">{player.wins}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-red-400 font-semibold">{player.losses}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-gray-300 font-mono">{getWinRate(player)}%</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};