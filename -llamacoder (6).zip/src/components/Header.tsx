import { Trophy, Shield, Home } from 'lucide-react';
import { Button } from './ui/button';

interface HeaderProps {
  activeTab: 'leaderboard' | 'admin';
  onTabChange: (tab: 'leaderboard' | 'admin') => void;
  onAdminClick: () => void;
  isAdmin: boolean;
}

export const Header = ({ activeTab, onTabChange, onAdminClick, isAdmin }: HeaderProps) => {
  return (
    <header className="border-b border-gray-800 bg-gray-900/50 backdrop-blur-sm sticky top-0 z-40">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-amber-500 to-orange-600 rounded-lg flex items-center justify-center">
              <Trophy className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">LuminariSMPS2</h1>
              <p className="text-xs text-gray-400">PvP Leaderboard</p>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex items-center gap-2">
            <Button
              variant={activeTab === 'leaderboard' ? 'default' : 'ghost'}
              onClick={() => onTabChange('leaderboard')}
              className="gap-2"
            >
              <Home className="w-4 h-4" />
              <span className="hidden sm:inline">Leaderboard</span>
            </Button>
            
            <Button
              variant={activeTab === 'admin' ? 'default' : 'ghost'}
              onClick={onAdminClick}
              className="gap-2"
            >
              <Shield className="w-4 h-4" />
              <span className="hidden sm:inline">Admin</span>
            </Button>
          </nav>
        </div>
      </div>
    </header>
  );
};