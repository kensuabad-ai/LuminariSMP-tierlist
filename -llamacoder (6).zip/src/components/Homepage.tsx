import { Trophy, Sword, Shield, Hammer, ArrowRight, Zap } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { TIER_SYSTEM } from '../utils/tierSystem';

export const Homepage = ({ onViewLeaderboard }: { onViewLeaderboard: () => void }) => {
  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="relative text-center py-20 overflow-hidden">
        {/* Background Glow Effect */}
        <div className="absolute inset-0 bg-gradient-to-b from-purple-900/20 via-transparent to-transparent pointer-events-none" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative max-w-4xl mx-auto px-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-500/10 border border-purple-500/20 rounded-full mb-6">
            <Zap className="w-4 h-4 text-purple-400" />
            <span className="text-sm font-semibold text-purple-300">Season 2 Now Live</span>
          </div>
          
          <h1 className="text-6xl md:text-7xl font-black text-white mb-4 tracking-tight">
            LUMINARI
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400"> SMP</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-400 mb-8 font-light">
            Competitive PvP Leaderboard & Tier System
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={onViewLeaderboard}
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white text-lg px-10 py-6 gap-2 font-semibold shadow-lg shadow-purple-500/25"
            >
              View Leaderboard
              <ArrowRight className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </section>
      
      {/* Tier Ladder System */}
      <section className="max-w-5xl mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="text-4xl font-bold text-white mb-3">Tier Ladder</h2>
          <p className="text-gray-400">Climb from Trial Warrior to Mythic Warlord</p>
        </div>
        
        <div className="bg-gray-900/50 backdrop-blur-sm rounded-2xl border border-gray-800 p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* High Tiers */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-purple-400 uppercase tracking-wider mb-3 px-2">High Tiers</div>
              {TIER_SYSTEM.filter(t => t.group === 'High').slice().reverse().map((tier) => (
                <div
                  key={tier.name}
                  className={`flex items-center justify-between p-4 rounded-lg border transition-all hover:border-purple-500/50 ${
                    tier.level === 10 
                      ? 'bg-gradient-to-r from-amber-500/10 to-orange-500/10 border-amber-500/20' 
                      : 'bg-gray-800/50 border-gray-700'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded flex items-center justify-center font-bold text-sm ${
                      tier.level === 10 
                        ? 'bg-gradient-to-br from-amber-500 to-orange-600 text-white' 
                        : 'bg-purple-500/20 text-purple-400'
                    }`}>
                      {tier.level}
                    </div>
                    <div>
                      <div className={`font-bold ${tier.level === 10 ? 'text-amber-400' : 'text-white'}`}>
                        {tier.name}
                      </div>
                      <div className="text-xs text-gray-500">{tier.title}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-mono text-gray-300">
                      {tier.minRating}–{tier.maxRating}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Low Tiers */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-blue-400 uppercase tracking-wider mb-3 px-2">Low Tiers</div>
              {TIER_SYSTEM.filter(t => t.group === 'Low').slice().reverse().map((tier) => (
                <div
                  key={tier.name}
                  className="flex items-center justify-between p-4 rounded-lg border bg-gray-800/30 border-gray-700/50 transition-all hover:border-blue-500/50"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded bg-blue-500/20 flex items-center justify-center font-bold text-sm text-blue-400">
                      {tier.level}
                    </div>
                    <div>
                      <div className="font-bold text-gray-300">
                        {tier.name}
                      </div>
                      <div className="text-xs text-gray-500">{tier.title}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-mono text-gray-400">
                      {tier.minRating}–{tier.maxRating}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="mt-8 pt-6 border-t border-gray-800 text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gray-800 rounded-lg">
              <Trophy className="w-4 h-4 text-amber-500" />
              <span className="text-sm text-gray-400">Max Rating Cap: <span className="text-white font-bold">500</span></span>
            </div>
          </div>
        </div>
      </section>
      
      {/* Ranked PvP Modes */}
      <section className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="text-4xl font-bold text-white mb-3">Ranked Modes</h2>
          <p className="text-gray-400">Compete across multiple game modes</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <ModeCard 
            icon={<Sword className="w-8 h-8" />}
            name="Axe PvP"
            points="+5 / +4 / +3"
            difficulty="Hard"
            color="from-red-500 to-rose-600"
            borderColor="border-red-500/20"
          />
          <ModeCard 
            icon={<Shield className="w-8 h-8" />}
            name="NethPot"
            points="+5 / +4 / +3"
            difficulty="Hard"
            color="from-purple-500 to-violet-600"
            borderColor="border-purple-500/20"
          />
          <ModeCard 
            icon={<Trophy className="w-8 h-8" />}
            name="SMP Combat"
            points="+4 / +3 / +2"
            difficulty="Medium"
            color="from-blue-500 to-cyan-600"
            borderColor="border-blue-500/20"
          />
          <ModeCard 
            icon={<Hammer className="w-8 h-8" />}
            name="Mace PvP"
            points="+5 / +4 / +3"
            difficulty="Extreme"
            color="from-orange-500 to-amber-600"
            borderColor="border-orange-500/20"
          />
        </div>
      </section>
    </div>
  );
};

interface ModeCardProps {
  icon: React.ReactNode;
  name: string;
  points: string;
  difficulty: string;
  color: string;
  borderColor: string;
}

const ModeCard = ({ icon, name, points, difficulty, color, borderColor }: ModeCardProps) => {
  const getDifficultyColor = (diff: string) => {
    switch (diff) {
      case 'Extreme': return 'bg-red-500/20 text-red-400 border-red-500/20';
      case 'Hard': return 'bg-orange-500/20 text-orange-400 border-orange-500/20';
      case 'Medium': return 'bg-blue-500/20 text-blue-400 border-blue-500/20';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/20';
    }
  };
  
  return (
    <Card className={`bg-gray-900/50 backdrop-blur-sm ${borderColor} border hover:border-opacity-50 transition-all hover:scale-105 hover:shadow-xl hover:shadow-purple-500/10`}>
      <CardContent className="p-6">
        <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center mb-4 shadow-lg`}>
          {icon}
        </div>
        <h3 className="text-lg font-bold text-white mb-2">{name}</h3>
        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Base Win</span>
            <span className="text-emerald-400 font-semibold">{points}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Difficulty</span>
            <span className={`px-2 py-0.5 rounded text-xs font-semibold border ${getDifficultyColor(difficulty)}`}>
              {difficulty}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};