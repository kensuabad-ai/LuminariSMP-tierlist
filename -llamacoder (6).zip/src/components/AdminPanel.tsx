import { useState } from 'react';
import { 
  Save, Play, History, Shield, Users, FileText, 
  Edit, Search, AlertTriangle, CheckCircle, XCircle,
  ArrowUp, ArrowDown, RefreshCw, Trash2, UserMinus, UserPlus
} from 'lucide-react';
import { PointRules, Player, Match, AuditLog } from '../types';
import { calculateMatch } from '../utils/pointCalculator';
import { getTierByRating } from '../utils/tierSystem';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';

interface AdminPanelProps {
  pointRules: PointRules;
  players: Player[];
  matches: Match[];
  auditLogs: AuditLog[];
  onUpdateRules: (rules: PointRules) => void;
  onRecordMatch: (match: any) => void;
  onEditMatch: (matchId: string, updatedMatch: Match) => void;
  onEditPlayer: (playerId: string, updates: Partial<Player>) => void;
  onRemovePlayer: (playerId: string) => void;
  onAddPlayer: (ign: string, rating: number) => void;
}

type AdminTab = 'dashboard' | 'record' | 'edit-match' | 'edit-player' | 'add-player' | 'manage-players' | 'audit';

export const AdminPanel = ({ 
  pointRules, 
  players, 
  matches, 
  auditLogs, 
  onUpdateRules, 
  onRecordMatch,
  onEditMatch,
  onEditPlayer,
  onRemovePlayer,
  onAddPlayer
}: AdminPanelProps) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');
  const [selectedMode, setSelectedMode] = useState<keyof PointRules>('axe');
  const [rules, setRules] = useState<PointRules>(pointRules);
  
  // Record Match State
  const [winnerId, setWinnerId] = useState('');
  const [loserId, setLoserId] = useState('');
  const [mode, setMode] = useState<'axe' | 'nethpot' | 'smp' | 'mace'>('axe');
  const [resultType, setResultType] = useState<'dominant' | 'clean' | 'close'>('dominant');
  const [matchPreview, setMatchPreview] = useState<any>(null);
  
  // Edit Match State
  const [searchMatchId, setSearchMatchId] = useState('');
  const [foundMatch, setFoundMatch] = useState<Match | null>(null);
  
  // Edit Player State
  const [searchPlayer, setSearchPlayer] = useState('');
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
  const [editRating, setEditRating] = useState('');
  const [editWins, setEditWins] = useState('');
  const [editLosses, setEditLosses] = useState('');

  // Add Player State
  const [newPlayerIgn, setNewPlayerIgn] = useState('');
  const [newPlayerRating, setNewPlayerRating] = useState('');

  // Manage Players State
  const [playerToRemoveId, setPlayerToRemoveId] = useState('');
  const [confirmDelete, setConfirmDelete] = useState(false);
  
  const todayMatches = matches.filter(m => m.date === new Date().toISOString().split('T')[0]).length;
  const pendingReports = 0;
  
  const handleRuleChange = (key: keyof PointRules[keyof PointRules], value: number) => {
    setRules(prev => ({
      ...prev,
      [selectedMode]: {
        ...prev[selectedMode],
        [key]: value
      }
    }));
  };
  
  const handleSaveRules = () => {
    onUpdateRules(rules);
  };
  
  const handlePreviewMatch = () => {
    if (winnerId && loserId && winnerId !== loserId) {
      const winner = players.find(p => p.id === winnerId);
      const loser = players.find(p => p.id === loserId);
      
      if (winner && loser) {
        const result = calculateMatch(
          winner,
          loser,
          mode,
          resultType,
          pointRules,
          matches
        );
        setMatchPreview(result);
      }
    }
  };
  
  const handleRecordMatch = () => {
    if (matchPreview) {
      onRecordMatch({
        ...matchPreview.match,
        winnerId,
        loserId,
        mode,
        resultType
      });
      setMatchPreview(null);
      setWinnerId('');
      setLoserId('');
      setResultType('dominant');
    }
  };
  
  const handleSearchMatch = () => {
    const match = matches.find(m => m.id === searchMatchId);
    setFoundMatch(match || null);
  };
  
  const handleSearchPlayer = () => {
    const player = players.find(p => p.ign.toLowerCase() === searchPlayer.toLowerCase());
    setSelectedPlayer(player || null);
    if (player) {
      setEditRating(player.rating.toString());
      setEditWins(player.wins.toString());
      setEditLosses(player.losses.toString());
    }
  };
  
  const handleUpdatePlayer = () => {
    if (selectedPlayer && editRating !== '' && editWins !== '' && editLosses !== '') {
      const newRating = parseInt(editRating);
      const newTier = getTierByRating(newRating);
      
      onEditPlayer(selectedPlayer.id, { 
        rating: newRating, 
        wins: parseInt(editWins), 
        losses: parseInt(editLosses),
        tier: newTier.name,
        tierGroup: newTier.group,
        tierLevel: newTier.level,
        title: newTier.title
      });
      setSelectedPlayer(null);
      setSearchPlayer('');
      setEditRating('');
      setEditWins('');
      setEditLosses('');
    }
  };

  const handleAddPlayer = () => {
    if (newPlayerIgn.trim() && newPlayerRating !== '') {
      const rating = parseInt(newPlayerRating);
      if (rating >= 0 && rating <= 500) {
        onAddPlayer(newPlayerIgn.trim(), rating);
        setNewPlayerIgn('');
        setNewPlayerRating('');
      }
    }
  };

  const handleRemovePlayer = () => {
    if (playerToRemoveId) {
      onRemovePlayer(playerToRemoveId);
      setPlayerToRemoveId('');
      setConfirmDelete(false);
    }
  };
  
  return (
    <div className="space-y-6">
      {/* Admin Navigation */}
      <div className="flex flex-wrap gap-2 border-b border-gray-700 pb-4">
        <Button
          variant={activeTab === 'dashboard' ? 'default' : 'ghost'}
          onClick={() => setActiveTab('dashboard')}
          className={activeTab === 'dashboard' ? 'bg-amber-500 text-amber-950' : 'text-gray-400'}
        >
          Dashboard
        </Button>
        <Button
          variant={activeTab === 'record' ? 'default' : 'ghost'}
          onClick={() => setActiveTab('record')}
          className={activeTab === 'record' ? 'bg-amber-500 text-amber-950' : 'text-gray-400'}
        >
          Record Match
        </Button>
        <Button
          variant={activeTab === 'add-player' ? 'default' : 'ghost'}
          onClick={() => setActiveTab('add-player')}
          className={activeTab === 'add-player' ? 'bg-emerald-500 text-emerald-950' : 'text-gray-400'}
        >
          Add Player
        </Button>
        <Button
          variant={activeTab === 'edit-player' ? 'default' : 'ghost'}
          onClick={() => setActiveTab('edit-player')}
          className={activeTab === 'edit-player' ? 'bg-amber-500 text-amber-950' : 'text-gray-400'}
        >
          Edit Player
        </Button>
        <Button
          variant={activeTab === 'manage-players' ? 'default' : 'ghost'}
          onClick={() => setActiveTab('manage-players')}
          className={activeTab === 'manage-players' ? 'bg-red-500 text-red-950' : 'text-gray-400'}
        >
          Manage Players
        </Button>
        <Button
          variant={activeTab === 'audit' ? 'default' : 'ghost'}
          onClick={() => setActiveTab('audit')}
          className={activeTab === 'audit' ? 'bg-amber-500 text-amber-950' : 'text-gray-400'}
        >
          Audit Log
        </Button>
      </div>
      
      {activeTab === 'dashboard' && (
        <>
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
                    <Play className="w-6 h-6 text-blue-400" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-white">{todayMatches}</div>
                    <div className="text-sm text-gray-400">Matches Today</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-amber-500/20 rounded-lg flex items-center justify-center">
                    <FileText className="w-6 h-6 text-amber-400" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-white">{pendingReports}</div>
                    <div className="text-sm text-gray-400">Pending Reports</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-emerald-500/20 rounded-lg flex items-center justify-center">
                    <Users className="w-6 h-6 text-emerald-400" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-white">{players.length}</div>
                    <div className="text-sm text-gray-400">Active Players</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Point Rules Editor */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-white flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  Point Rules Editor
                </CardTitle>
                <div className="flex items-center gap-3">
                  <Select value={selectedMode} onValueChange={(v: any) => setSelectedMode(v)}>
                    <SelectTrigger className="w-40 bg-gray-900 border-gray-700 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-900 border-gray-700">
                      <SelectItem value="axe">Axe PvP</SelectItem>
                      <SelectItem value="nethpot">NethPot</SelectItem>
                      <SelectItem value="smp">SMP Combat</SelectItem>
                      <SelectItem value="mace">Mace PvP</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button onClick={handleSaveRules} className="bg-emerald-500 hover:bg-emerald-600 text-emerald-950 gap-2">
                    <Save className="w-4 h-4" />
                    Save Rules
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <RuleInput label="Dominant" value={rules[selectedMode].dominant} onChange={(v) => handleRuleChange('dominant', v)} />
                <RuleInput label="Clean" value={rules[selectedMode].clean} onChange={(v) => handleRuleChange('clean', v)} />
                <RuleInput label="Close" value={rules[selectedMode].close} onChange={(v) => handleRuleChange('close', v)} />
                <RuleInput label="Max Gain" value={rules[selectedMode].maxGain} onChange={(v) => handleRuleChange('maxGain', v)} />
                <RuleInput label="Loss vs Higher" value={rules[selectedMode].lossHigher} onChange={(v) => handleRuleChange('lossHigher', v)} />
                <RuleInput label="Loss Equal" value={rules[selectedMode].lossEqual} onChange={(v) => handleRuleChange('lossEqual', v)} />
                <RuleInput label="Loss Lower" value={rules[selectedMode].lossLower} onChange={(v) => handleRuleChange('lossLower', v)} />
                <RuleInput label="Loss Much Lower" value={rules[selectedMode].lossMuchLower} onChange={(v) => handleRuleChange('lossMuchLower', v)} />
                <RuleInput label="Beat Higher Bonus" value={rules[selectedMode].beatHigherBonus} onChange={(v) => handleRuleChange('beatHigherBonus', v)} />
                <RuleInput label="Beat Lower Max" value={rules[selectedMode].beatLowerMax} onChange={(v) => handleRuleChange('beatLowerMax', v)} />
                <RuleInput label="Anti-Farm Mult" value={rules[selectedMode].antiFarmMult} onChange={(v) => handleRuleChange('antiFarmMult', v)} />
              </div>
            </CardContent>
          </Card>
        </>
      )}

      {activeTab === 'add-player' && (
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <UserPlus className="w-5 h-5 text-emerald-400" />
              Add New Player
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">In-Game Name (IGN)</label>
                <Input
                  placeholder="Enter player IGN..."
                  value={newPlayerIgn}
                  onChange={(e) => setNewPlayerIgn(e.target.value)}
                  className="bg-gray-900 border-gray-700 text-white"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Initial Rating (0-500)</label>
                <Input
                  type="number"
                  min="0"
                  max="500"
                  placeholder="Enter initial rating..."
                  value={newPlayerRating}
                  onChange={(e) => setNewPlayerRating(e.target.value)}
                  className="bg-gray-900 border-gray-700 text-white"
                />
                {newPlayerRating && (
                  <div className="flex items-center gap-2 text-sm">
                    <span className="text-gray-400">Starting Tier:</span>
                    <span className={`font-bold ${
                      getTierByRating(parseInt(newPlayerRating)).group === 'High' 
                        ? 'text-amber-400' 
                        : 'text-blue-400'
                    }`}>
                      {getTierByRating(parseInt(newPlayerRating)).name}
                    </span>
                  </div>
                )}
              </div>

              <Button 
                onClick={handleAddPlayer}
                disabled={!newPlayerIgn.trim() || newPlayerRating === ''}
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-emerald-950"
              >
                <UserPlus className="w-4 h-4 mr-2" />
                Add Player to Leaderboard
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
      
      {activeTab === 'record' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Match Input Form */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Play className="w-5 h-5" />
                Record Match
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Game Mode</label>
                <Select value={mode} onValueChange={(v: any) => setMode(v)}>
                  <SelectTrigger className="bg-gray-900 border-gray-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-900 border-gray-700">
                    <SelectItem value="axe">Axe PvP</SelectItem>
                    <SelectItem value="nethpot">NethPot</SelectItem>
                    <SelectItem value="smp">SMP Combat</SelectItem>
                    <SelectItem value="mace">Mace PvP</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Winner</label>
                <Select value={winnerId} onValueChange={setWinnerId}>
                  <SelectTrigger className="bg-gray-900 border-gray-700 text-white">
                    <SelectValue placeholder="Select winner" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-900 border-gray-700 max-h-60">
                    {players.map(p => (
                      <SelectItem key={p.id} value={p.id}>
                        {p.ign} ({p.rating}) - {p.tier}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Loser</label>
                <Select value={loserId} onValueChange={setLoserId}>
                  <SelectTrigger className="bg-gray-900 border-gray-700 text-white">
                    <SelectValue placeholder="Select loser" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-900 border-gray-700 max-h-60">
                    {players.map(p => (
                      <SelectItem key={p.id} value={p.id}>
                        {p.ign} ({p.rating}) - {p.tier}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Result Type</label>
                <Select value={resultType} onValueChange={(v: any) => setResultType(v)}>
                  <SelectTrigger className="bg-gray-900 border-gray-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-900 border-gray-700">
                    <SelectItem value="dominant">Dominant (2-0)</SelectItem>
                    <SelectItem value="clean">Clean (2-1)</SelectItem>
                    <SelectItem value="close">Close (2-1 close)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                onClick={handlePreviewMatch}
                disabled={!winnerId || !loserId || winnerId === loserId}
                className="w-full bg-blue-500 hover:bg-blue-600 text-white"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Preview Calculation
              </Button>
            </CardContent>
          </Card>
          
          {/* Match Preview */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Match Preview</CardTitle>
            </CardHeader>
            <CardContent>
              {matchPreview ? (
                <div className="space-y-4">
                  {matchPreview.preview.antiFarmWarning && (
                    <div className="flex items-start gap-2 p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg">
                      <AlertTriangle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                      <p className="text-sm text-amber-400">{matchPreview.preview.antiFarmWarning}</p>
                    </div>
                  )}
                  
                  <div className="space-y-3">
                    <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-white">Winner</span>
                        <span className="text-emerald-400 font-bold">+{matchPreview.preview.winnerPoints}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-400">{players.find(p => p.id === winnerId)?.ign}</span>
                        <div className="text-right">
                          <span className="text-gray-400">{matchPreview.preview.winnerOldRating}</span>
                          <ArrowUp className="w-4 h-4 text-emerald-400 inline mx-1" />
                          <span className="text-white font-bold">{matchPreview.preview.winnerNewRating}</span>
                        </div>
                      </div>
                      {matchPreview.preview.winnerTierChange && (
                        <div className="mt-2 text-sm text-amber-400">
                          Tier Change: {matchPreview.preview.winnerTierChange}
                        </div>
                      )}
                    </div>
                    
                    <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-white">Loser</span>
                        <span className="text-red-400 font-bold">{matchPreview.preview.loserPoints}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-400">{players.find(p => p.id === loserId)?.ign}</span>
                        <div className="text-right">
                          <span className="text-gray-400">{matchPreview.preview.loserOldRating}</span>
                          <ArrowDown className="w-4 h-4 text-red-400 inline mx-1" />
                          <span className="text-white font-bold">{matchPreview.preview.loserNewRating}</span>
                        </div>
                      </div>
                      {matchPreview.preview.loserTierChange && (
                        <div className="mt-2 text-sm text-amber-400">
                          Tier Change: {matchPreview.preview.loserTierChange}
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <Button 
                    onClick={handleRecordMatch}
                    className="w-full bg-amber-500 hover:bg-amber-600 text-amber-950"
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Confirm & Record Match
                  </Button>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  Select players and mode to preview calculation
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === 'edit-player' && (
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Edit className="w-5 h-5" />
              Edit Player Stats
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Search Section */}
            <div className="flex gap-2">
              <Input
                placeholder="Search by IGN..."
                value={searchPlayer}
                onChange={(e) => setSearchPlayer(e.target.value)}
                className="bg-gray-900 border-gray-700 text-white"
              />
              <Button onClick={handleSearchPlayer} className="bg-blue-500 hover:bg-blue-600 text-white">
                <Search className="w-4 h-4 mr-2" />
                Search
              </Button>
            </div>
            
            {/* Edit Form */}
            {selectedPlayer && (
              <div className="space-y-4 p-4 bg-gray-900 rounded-lg border border-gray-700">
                <div className="flex items-center gap-4 pb-4 border-b border-gray-700">
                  <div className={`w-16 h-16 rounded-full flex items-center justify-center text-white font-bold text-xl ${
                    selectedPlayer.tierGroup === 'High' 
                      ? 'bg-gradient-to-br from-amber-500 to-orange-600' 
                      : 'bg-gradient-to-br from-blue-500 to-purple-600'
                  }`}>
                    {selectedPlayer.ign.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">{selectedPlayer.ign}</h3>
                    <p className="text-sm text-gray-400">{selectedPlayer.tier} • {selectedPlayer.title}</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Rating (0-500)</label>
                    <Input
                      type="number"
                      min="0"
                      max="500"
                      value={editRating}
                      onChange={(e) => setEditRating(e.target.value)}
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                    {editRating && (
                      <p className="text-xs text-gray-500">
                        New Tier: {getTierByRating(parseInt(editRating)).name}
                      </p>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Wins</label>
                    <Input
                      type="number"
                      min="0"
                      value={editWins}
                      onChange={(e) => setEditWins(e.target.value)}
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-300">Losses</label>
                    <Input
                      type="number"
                      min="0"
                      value={editLosses}
                      onChange={(e) => setEditLosses(e.target.value)}
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                </div>

                {/* Mode Stats Preview */}
                <div className="pt-4 border-t border-gray-700">
                  <p className="text-xs text-gray-500 mb-2">Current Mode Stats (Read Only)</p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                    {Object.entries(selectedPlayer.modeStats).map(([mode, stats]) => (
                      <div key={mode} className="bg-gray-800 p-2 rounded">
                        <div className="text-gray-400 capitalize">{mode}</div>
                        <div className="text-white font-bold">{stats.wins}W - {stats.losses}L</div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="flex gap-2 pt-2">
                  <Button 
                    onClick={handleUpdatePlayer}
                    className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-emerald-950"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Save Changes
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => {
                      setSelectedPlayer(null);
                      setSearchPlayer('');
                    }}
                    className="flex-1 border-gray-700 text-gray-300"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {activeTab === 'manage-players' && (
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <UserMinus className="w-5 h-5 text-red-400" />
              Remove Player
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">Select Player to Remove</label>
                <Select value={playerToRemoveId} onValueChange={(v) => { setPlayerToRemoveId(v); setConfirmDelete(false); }}>
                  <SelectTrigger className="bg-gray-900 border-gray-700 text-white">
                    <SelectValue placeholder="Choose a player..." />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-900 border-gray-700 max-h-60">
                    {players.map(p => (
                      <SelectItem key={p.id} value={p.id}>
                        {p.ign} ({p.rating}) - {p.tier}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {playerToRemoveId && (
                <div className="p-4 bg-gray-900 rounded-lg border border-gray-700">
                  {(() => {
                    const player = players.find(p => p.id === playerToRemoveId);
                    if (!player) return null;
                    return (
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm ${
                            player.tierGroup === 'High' 
                              ? 'bg-gradient-to-br from-amber-500 to-orange-600' 
                              : 'bg-gradient-to-br from-blue-500 to-purple-600'
                          }`}>
                            {player.ign.slice(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-bold text-white">{player.ign}</div>
                            <div className="text-sm text-gray-400">{player.tier} • {player.rating} Rating</div>
                          </div>
                        </div>
                        <div className="text-sm text-gray-500">
                          {player.wins}W - {player.losses}L
                        </div>
                      </div>
                    );
                  })()}
                </div>
              )}

              {playerToRemoveId && !confirmDelete && (
                <Button 
                  onClick={() => setConfirmDelete(true)}
                  variant="destructive"
                  className="w-full bg-red-600 hover:bg-red-700"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Remove Player
                </Button>
              )}

              {confirmDelete && (
                <div className="space-y-3">
                  <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
                    <p className="text-sm text-red-400 font-semibold mb-2">
                      Are you sure you want to remove this player?
                    </p>
                    <p className="text-xs text-gray-400">
                      This action cannot be undone. The player will be permanently deleted from the leaderboard.
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      onClick={handleRemovePlayer}
                      className="flex-1 bg-red-600 hover:bg-red-700"
                    >
                      Yes, Remove
                    </Button>
                    <Button 
                      onClick={() => setConfirmDelete(false)}
                      variant="outline"
                      className="flex-1 border-gray-700 text-gray-300"
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
      
      {activeTab === 'audit' && (
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <History className="w-5 h-5" />
              Audit Log
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {auditLogs.slice(0, 10).map(log => (
                <div key={log.id} className="p-3 bg-gray-900 rounded-lg border border-gray-700">
                  <div className="flex items-start justify-between">
                    <p className="text-sm text-gray-300">{log.action}</p>
                    <span className="text-xs text-gray-500">
                      {new Date(log.timestamp).toLocaleString()}
                    </span>
                  </div>
                  {log.admin && (
                    <p className="text-xs text-gray-500 mt-1">By: {log.admin}</p>
                  )}
                </div>
              ))}
              {auditLogs.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  No audit logs yet
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

const RuleInput = ({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) => (
  <div className="space-y-1">
    <label className="text-xs font-medium text-gray-400">{label}</label>
    <Input
      type="number"
      value={value}
      onChange={(e) => onChange(parseFloat(e.target.value) || 0)}
      className="bg-gray-900 border-gray-700 text-white"
    />
  </div>
);