export interface Tier {
  name: string;
  group: 'Low' | 'High';
  level: number;
  minRating: number;
  maxRating: number;
  title: string;
}

// New Tier System: Low T5 -> High T5 -> Low T4 -> High T4 ... -> Low T1 -> High T1
export const TIER_SYSTEM: Tier[] = [
  // Top Tiers
  { name: 'High T1', group: 'High', level: 10, minRating: 450, maxRating: 500, title: 'Legendary God' },
  { name: 'Low T1', group: 'Low', level: 9, minRating: 400, maxRating: 449, title: 'Elite Warrior' },
  { name: 'High T2', group: 'High', level: 8, minRating: 350, maxRating: 399, title: 'Master Duelist' },
  { name: 'Low T2', group: 'Low', level: 7, minRating: 300, maxRating: 349, title: 'Veteran Fighter' },
  { name: 'High T3', group: 'High', level: 6, minRating: 250, maxRating: 299, title: 'Skilled Combatant' },
  { name: 'Low T3', group: 'Low', level: 5, minRating: 200, maxRating: 249, title: 'Competitive Player' },
  { name: 'High T4', group: 'High', level: 4, minRating: 150, maxRating: 199, title: 'Rising Star' },
  { name: 'Low T4', group: 'Low', level: 3, minRating: 100, maxRating: 149, title: 'Apprentice' },
  { name: 'High T5', group: 'High', level: 2, minRating: 50, maxRating: 99, title: 'Trial Warrior' },
  { name: 'Low T5', group: 'Low', level: 1, minRating: 0, maxRating: 49, title: 'Beginner' },
];

export const getTierByRating = (rating: number): Tier => {
  // Find the tier where rating falls within min/max range
  const tier = TIER_SYSTEM.find(t => rating >= t.minRating && rating <= t.maxRating);
  return tier || TIER_SYSTEM[TIER_SYSTEM.length - 1]; // Default to lowest if not found
};

export const getNextTier = (currentRating: number): Tier | null => {
  const currentTier = getTierByRating(currentRating);
  const currentIndex = TIER_SYSTEM.findIndex(t => t.level === currentTier.level);
  if (currentIndex > 0) {
    return TIER_SYSTEM[currentIndex - 1];
  }
  return null;
};

export const getPreviousTier = (currentRating: number): Tier | null => {
  const currentTier = getTierByRating(currentRating);
  const currentIndex = TIER_SYSTEM.findIndex(t => t.level === currentTier.level);
  if (currentIndex < TIER_SYSTEM.length - 1) {
    return TIER_SYSTEM[currentIndex + 1];
  }
  return null;
};