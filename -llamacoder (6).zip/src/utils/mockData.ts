import { Player, Match, PointRules, Report, AuditLog } from '../types';

export const mockData: {
  players: Player[];
  matches: Match[];
  pointRules: PointRules;
  reports: Report[];
  auditLogs: AuditLog[];
} = {
  players: [
    {
      id: '1',
      ign: 'Kensu',
      rating: 1850,
      wins: 45,
      losses: 12,
      tier: 'High T1',
      tierGroup: 'High',
      tierLevel: 10,
      title: 'Legendary God',
      modeStats: {
        axe: { wins: 15, losses: 4 },
        nethpot: { wins: 12, losses: 3 },
        smp: { wins: 10, losses: 3 },
        mace: { wins: 8, losses: 2 }
      }
    },
    {
      id: '2',
      ign: 'Viper',
      rating: 1780,
      wins: 38,
      losses: 15,
      tier: 'Low T1',
      tierGroup: 'Low',
      tierLevel: 9,
      title: 'Elite Warrior',
      modeStats: {
        axe: { wins: 12, losses: 5 },
        nethpot: { wins: 10, losses: 4 },
        smp: { wins: 8, losses: 3 },
        mace: { wins: 8, losses: 3 }
      }
    },
    {
      id: '3',
      ign: 'Shadow',
      rating: 1720,
      wins: 42,
      losses: 18,
      tier: 'Low T1',
      tierGroup: 'Low',
      tierLevel: 9,
      title: 'Elite Warrior',
      modeStats: {
        axe: { wins: 14, losses: 6 },
        nethpot: { wins: 11, losses: 5 },
        smp: { wins: 9, losses: 4 },
        mace: { wins: 8, losses: 3 }
      }
    },
    {
      id: '4',
      ign: 'Phoenix',
      rating: 1650,
      wins: 35,
      losses: 20,
      tier: 'High T2',
      tierGroup: 'High',
      tierLevel: 8,
      title: 'Master Duelist',
      modeStats: {
        axe: { wins: 10, losses: 6 },
        nethpot: { wins: 9, losses: 5 },
        smp: { wins: 8, losses: 5 },
        mace: { wins: 8, losses: 4 }
      }
    },
    {
      id: '5',
      ign: 'Storm',
      rating: 1580,
      wins: 30,
      losses: 22,
      tier: 'Low T2',
      tierGroup: 'Low',
      tierLevel: 7,
      title: 'Veteran Fighter',
      modeStats: {
        axe: { wins: 8, losses: 6 },
        nethpot: { wins: 8, losses: 6 },
        smp: { wins: 7, losses: 5 },
        mace: { wins: 7, losses: 5 }
      }
    },
    {
      id: '6',
      ign: 'Blaze',
      rating: 1520,
      wins: 28,
      losses: 25,
      tier: 'Low T2',
      tierGroup: 'Low',
      tierLevel: 7,
      title: 'Veteran Fighter',
      modeStats: {
        axe: { wins: 7, losses: 7 },
        nethpot: { wins: 7, losses: 6 },
        smp: { wins: 7, losses: 6 },
        mace: { wins: 7, losses: 6 }
      }
    },
    {
      id: '7',
      ign: 'Frost',
      rating: 1450,
      wins: 25,
      losses: 28,
      tier: 'High T3',
      tierGroup: 'High',
      tierLevel: 6,
      title: 'Skilled Combatant',
      modeStats: {
        axe: { wins: 6, losses: 8 },
        nethpot: { wins: 6, losses: 7 },
        smp: { wins: 7, losses: 7 },
        mace: { wins: 6, losses: 6 }
      }
    },
    {
      id: '8',
      ign: 'Thunder',
      rating: 1380,
      wins: 22,
      losses: 30,
      tier: 'Low T3',
      tierGroup: 'Low',
      tierLevel: 5,
      title: 'Competitive Player',
      modeStats: {
        axe: { wins: 5, losses: 8 },
        nethpot: { wins: 6, losses: 8 },
        smp: { wins: 6, losses: 7 },
        mace: { wins: 5, losses: 7 }
      }
    },
    {
      id: '9',
      ign: 'Mystic',
      rating: 1320,
      wins: 20,
      losses: 32,
      tier: 'Low T3',
      tierGroup: 'Low',
      tierLevel: 5,
      title: 'Competitive Player',
      modeStats: {
        axe: { wins: 5, losses: 8 },
        nethpot: { wins: 5, losses: 8 },
        smp: { wins: 5, losses: 8 },
        mace: { wins: 5, losses: 8 }
      }
    },
    {
      id: '10',
      ign: 'Nova',
      rating: 1250,
      wins: 18,
      losses: 35,
      tier: 'High T4',
      tierGroup: 'High',
      tierLevel: 4,
      title: 'Rising Star',
      modeStats: {
        axe: { wins: 4, losses: 9 },
        nethpot: { wins: 5, losses: 9 },
        smp: { wins: 5, losses: 9 },
        mace: { wins: 4, losses: 8 }
      }
    },
    {
      id: '11',
      ign: 'Echo',
      rating: 1180,
      wins: 15,
      losses: 38,
      tier: 'Low T4',
      tierGroup: 'Low',
      tierLevel: 3,
      title: 'Apprentice',
      modeStats: {
        axe: { wins: 4, losses: 10 },
        nethpot: { wins: 4, losses: 10 },
        smp: { wins: 4, losses: 9 },
        mace: { wins: 3, losses: 9 }
      }
    },
    {
      id: '12',
      ign: 'Rift',
      rating: 1120,
      wins: 12,
      losses: 40,
      tier: 'Low T4',
      tierGroup: 'Low',
      tierLevel: 3,
      title: 'Apprentice',
      modeStats: {
        axe: { wins: 3, losses: 10 },
        nethpot: { wins: 3, losses: 10 },
        smp: { wins: 3, losses: 10 },
        mace: { wins: 3, losses: 10 }
      }
    },
    {
      id: '13',
      ign: 'Zenith',
      rating: 1050,
      wins: 10,
      losses: 42,
      tier: 'High T5',
      tierGroup: 'High',
      tierLevel: 2,
      title: 'Trial Warrior',
      modeStats: {
        axe: { wins: 2, losses: 11 },
        nethpot: { wins: 3, losses: 11 },
        smp: { wins: 3, losses: 10 },
        mace: { wins: 2, losses: 10 }
      }
    },
    {
      id: '14',
      ign: 'Apex',
      rating: 980,
      wins: 8,
      losses: 45,
      tier: 'Low T5',
      tierGroup: 'Low',
      tierLevel: 1,
      title: 'Beginner',
      modeStats: {
        axe: { wins: 2, losses: 12 },
        nethpot: { wins: 2, losses: 12 },
        smp: { wins: 2, losses: 11 },
        mace: { wins: 2, losses: 10 }
      }
    },
    {
      id: '15',
      ign: 'Crimson',
      rating: 1750,
      wins: 36,
      losses: 16,
      tier: 'Low T1',
      tierGroup: 'Low',
      tierLevel: 9,
      title: 'Elite Warrior',
      modeStats: {
        axe: { wins: 11, losses: 5 },
        nethpot: { wins: 10, losses: 4 },
        smp: { wins: 8, losses: 4 },
        mace: { wins: 7, losses: 3 }
      }
    },
    {
      id: '16',
      ign: 'Obsidian',
      rating: 1680,
      wins: 33,
      losses: 19,
      tier: 'High T2',
      tierGroup: 'High',
      tierLevel: 8,
      title: 'Master Duelist',
      modeStats: {
        axe: { wins: 10, losses: 6 },
        nethpot: { wins: 9, losses: 5 },
        smp: { wins: 7, losses: 5 },
        mace: { wins: 7, losses: 3 }
      }
    },
    {
      id: '17',
      ign: 'Sapphire',
      rating: 1600,
      wins: 29,
      losses: 23,
      tier: 'Low T2',
      tierGroup: 'Low',
      tierLevel: 7,
      title: 'Veteran Fighter',
      modeStats: {
        axe: { wins: 8, losses: 6 },
        nethpot: { wins: 7, losses: 6 },
        smp: { wins: 7, losses: 6 },
        mace: { wins: 7, losses: 5 }
      }
    },
    {
      id: '18',
      ign: 'Ruby',
      rating: 1480,
      wins: 26,
      losses: 27,
      tier: 'High T3',
      tierGroup: 'High',
      tierLevel: 6,
      title: 'Skilled Combatant',
      modeStats: {
        axe: { wins: 6, losses: 7 },
        nethpot: { wins: 7, losses: 7 },
        smp: { wins: 7, losses: 7 },
        mace: { wins: 6, losses: 6 }
      }
    },
    {
      id: '19',
      ign: 'Emerald',
      rating: 1400,
      wins: 23,
      losses: 30,
      tier: 'Low T3',
      tierGroup: 'Low',
      tierLevel: 5,
      title: 'Competitive Player',
      modeStats: {
        axe: { wins: 5, losses: 8 },
        nethpot: { wins: 6, losses: 8 },
        smp: { wins: 6, losses: 7 },
        mace: { wins: 6, losses: 7 }
      }
    },
    {
      id: '20',
      ign: 'Amethyst',
      rating: 1300,
      wins: 19,
      losses: 34,
      tier: 'Low T3',
      tierGroup: 'Low',
      tierLevel: 5,
      title: 'Competitive Player',
      modeStats: {
        axe: { wins: 5, losses: 9 },
        nethpot: { wins: 4, losses: 9 },
        smp: { wins: 5, losses: 8 },
        mace: { wins: 5, losses: 8 }
      }
    }
  ],

  matches: [
    {
      id: '1',
      winnerId: '1',
      loserId: '2',
      mode: 'axe',
      resultType: 'dominant',
      date: '2024-01-15',
      winnerRating: 1850,
      loserRating: 1780,
      winnerPoints: 3,
      loserPoints: 0
    },
    {
      id: '2',
      winnerId: '3',
      loserId: '4',
      mode: 'nethpot',
      resultType: 'clean',
      date: '2024-01-15',
      winnerRating: 1720,
      loserRating: 1650,
      winnerPoints: 4,
      loserPoints: -4
    },
    {
      id: '3',
      winnerId: '2',
      loserId: '5',
      mode: 'smp',
      resultType: 'close',
      date: '2024-01-14',
      winnerRating: 1780,
      loserRating: 1580,
      winnerPoints: 3,
      loserPoints: -3
    },
    {
      id: '4',
      winnerId: '1',
      loserId: '3',
      mode: 'mace',
      resultType: 'dominant',
      date: '2024-01-14',
      winnerRating: 1830,
      loserRating: 1720,
      winnerPoints: 3,
      loserPoints: 0
    },
    {
      id: '5',
      winnerId: '4',
      loserId: '6',
      mode: 'axe',
      resultType: 'clean',
      date: '2024-01-13',
      winnerRating: 1650,
      loserRating: 1520,
      winnerPoints: 4,
      loserPoints: -4
    }
  ],

  pointRules: {
    axe: {
      dominant: 3,
      clean: 4,
      close: 3,
      lossHigher: -2,
      lossEqual: -3,
      lossLower: -4,
      lossMuchLower: -5,
      dominantLossDown: 0,
      tier1Bonus: 1,
      tier2Bonus: 2,
      lowerTierCap: 1,
      maxCap: 5,
      repeatMultiplier: 0.25,
      gapMultiplier: 0.5,
      maxGain: 5,
      beatHigherBonus: 1,
      beatLowerMax: 5,
      antiFarmMult: 0.25
    },
    nethpot: {
      dominant: 3,
      clean: 4,
      close: 3,
      lossHigher: -2,
      lossEqual: -3,
      lossLower: -4,
      lossMuchLower: -5,
      dominantLossDown: 0,
      tier1Bonus: 1,
      tier2Bonus: 2,
      lowerTierCap: 1,
      maxCap: 5,
      repeatMultiplier: 0.25,
      gapMultiplier: 0.5,
      maxGain: 5,
      beatHigherBonus: 1,
      beatLowerMax: 5,
      antiFarmMult: 0.25
    },
    smp: {
      dominant: 3,
      clean: 4,
      close: 3,
      lossHigher: -2,
      lossEqual: -3,
      lossLower: -4,
      lossMuchLower: -5,
      dominantLossDown: 0,
      tier1Bonus: 1,
      tier2Bonus: 2,
      lowerTierCap: 1,
      maxCap: 5,
      repeatMultiplier: 0.25,
      gapMultiplier: 0.5,
      maxGain: 5,
      beatHigherBonus: 1,
      beatLowerMax: 5,
      antiFarmMult: 0.25
    },
    mace: {
      dominant: 3,
      clean: 4,
      close: 3,
      lossHigher: -2,
      lossEqual: -3,
      lossLower: -4,
      lossMuchLower: -5,
      dominantLossDown: 0,
      tier1Bonus: 1,
      tier2Bonus: 2,
      lowerTierCap: 1,
      maxCap: 5,
      repeatMultiplier: 0.25,
      gapMultiplier: 0.5,
      maxGain: 5,
      beatHigherBonus: 1,
      beatLowerMax: 5,
      antiFarmMult: 0.25
    }
  },

  reports: [],

  auditLogs: []
};