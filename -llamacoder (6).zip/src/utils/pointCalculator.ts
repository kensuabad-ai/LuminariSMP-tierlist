import { Player, Match, PointRules, ModePointRules } from '../types';

interface MatchInput {
  winnerId: string;
  loserId: string;
  mode: 'axe' | 'nethpot' | 'smp' | 'mace';
  winnerRounds: number;
  loserRounds: number;
  isCloseFinal: boolean;
}

interface CalculationResult {
  winner: Player;
  loser: Player;
  match: Match;
}

const determineResultType = (
  winnerRounds: number,
  loserRounds: number,
  isCloseFinal: boolean
): 'dominant' | 'clean' | 'close' => {
  // Updated logic: 3-0 is Dominant
  if (winnerRounds === 3 && loserRounds === 0) {
    return 'dominant';
  }
  
  // 3-1 is Clean
  if (winnerRounds === 3 && loserRounds === 1) {
    return 'clean';
  }
  
  // 3-2 is Close or Clean depending on flag
  if (winnerRounds === 3 && loserRounds === 2) {
    return isCloseFinal ? 'close' : 'clean';
  }

  // Fallback for legacy 2-0/2-1 matches (if any exist in data)
  if (winnerRounds === 2 && loserRounds === 0) return 'dominant';
  if (winnerRounds === 2 && loserRounds === 1) return isCloseFinal ? 'close' : 'clean';

  // Default fallback
  return 'clean';
};

const getTierLevel = (tierGroup: string, tierName: string): number => {
  if (tierGroup === 'T1') return tierName === 'High T1' ? 3 : 2;
  if (tierGroup === 'T2') return tierName === 'High T2' ? 3 : tierName === 'T2' ? 2 : 1;
  if (tierGroup === 'T3') return tierName === 'High T3' ? 3 : tierName === 'T3' ? 2 : 1;
  if (tierGroup === 'T4') return tierName === 'High T4' ? 3 : tierName === 'T4' ? 2 : 1;
  return 1;
};

const updateTier = (rating: number): { tier: string; tierGroup: string; tierLevel: number } => {
  if (rating >= 1800) return { tier: 'High T1', tierGroup: 'T1', tierLevel: 3 };
  if (rating >= 1600) return { tier: 'T1', tierGroup: 'T1', tierLevel: 2 };
  if (rating >= 1400) return { tier: 'High T2', tierGroup: 'T2', tierLevel: 3 };
  if (rating >= 1200) return { tier: 'T2', tierGroup: 'T2', tierLevel: 2 };
  if (rating >= 1000) return { tier: 'High T3', tierGroup: 'T3', tierLevel: 3 };
  if (rating >= 800) return { tier: 'T3', tierGroup: 'T3', tierLevel: 2 };
  if (rating >= 600) return { tier: 'High T4', tierGroup: 'T4', tierLevel: 3 };
  if (rating >= 400) return { tier: 'T4', tierGroup: 'T4', tierLevel: 2 };
  return { tier: 'T5', tierGroup: 'T5', tierLevel: 1 };
};

export const calculatePoints = (
  matchInput: MatchInput,
  winner: Player,
  loser: Player,
  rules: PointRules,
  recentMatches: Match[]
): CalculationResult => {
  const modeRules: ModePointRules = rules[matchInput.mode];
  const resultType = determineResultType(matchInput.winnerRounds, matchInput.loserRounds, matchInput.isCloseFinal);
  
  // Base points
  let winnerPoints = modeRules[resultType];
  let loserPoints = 0;

  // Determine loss type for loser
  const ratingDiff = winner.rating - loser.rating;
  let lossType: 'lossUp' | 'lossEqual' | 'lossDown' | 'dominantLossDown';
  
  if (resultType === 'dominant') {
    lossType = 'dominantLossDown';
  } else if (ratingDiff > 100) {
    lossType = 'lossDown';
  } else if (ratingDiff < -100) {
    lossType = 'lossUp';
  } else {
    lossType = 'lossEqual';
  }

  loserPoints = modeRules[lossType];

  // Apply Tier Bonus
  const winnerTierLevel = getTierLevel(winner.tierGroup, winner.tier);
  if (winnerTierLevel >= 2) {
    winnerPoints += winnerTierLevel === 2 ? modeRules.tier1Bonus : modeRules.tier2Bonus;
  }

  // Apply Caps
  if (winnerPoints > modeRules.maxCap) winnerPoints = modeRules.maxCap;
  
  const loserTierLevel = getTierLevel(loser.tierGroup, loser.tier);
  if (winnerTierLevel - loserTierLevel >= 2 && winnerPoints > modeRules.lowerTierCap) {
    winnerPoints = modeRules.lowerTierCap;
  }

  // Anti-farm: Repeat opponent
  const recentOpponentIds = recentMatches
    .filter(m => m.winnerId === winner.id || m.loserId === winner.id)
    .slice(0, 5)
    .map(m => m.winnerId === winner.id ? m.loserId : m.winnerId);
  
  const repeatCount = recentOpponentIds.filter(id => id === loser.id).length;
  if (repeatCount > 0) {
    winnerPoints *= modeRules.repeatMultiplier;
    loserPoints *= modeRules.repeatMultiplier;
  }

  // Anti-farm: Large gap
  if (Math.abs(ratingDiff) >= 400) {
    winnerPoints *= modeRules.gapMultiplier;
    loserPoints *= modeRules.gapMultiplier;
  }

  // Round points
  winnerPoints = Math.round(winnerPoints);
  loserPoints = Math.round(loserPoints);

  // Update ratings
  const newWinnerRating = winner.rating + winnerPoints;
  const newLoserRating = loser.rating + loserPoints;

  // Update tiers
  const winnerTierInfo = updateTier(newWinnerRating);
  const loserTierInfo = updateTier(newLoserRating);

  const updatedWinner: Player = {
    ...winner,
    rating: newWinnerRating,
    ...winnerTierInfo,
    wins: winner.wins + 1,
    title: newWinnerRating >= 1600 ? 'Elite Duelist' : newWinnerRating >= 1400 ? 'Master Combatant' : 'Competitive Player'
  };

  const updatedLoser: Player = {
    ...loser,
    rating: newLoserRating,
    ...loserTierInfo,
    losses: loser.losses + 1
  };

  // Update mode stats
  updatedWinner.modeStats[matchInput.mode].wins += 1;
  updatedLoser.modeStats[matchInput.mode].losses += 1;

  const newMatch: Match = {
    id: Date.now().toString(),
    winnerId: winner.id,
    loserId: loser.id,
    mode: matchInput.mode,
    resultType,
    date: new Date().toISOString().split('T')[0],
    winnerRating: winner.rating,
    loserRating: loser.rating,
    winnerPoints,
    loserPoints
  };

  return {
    winner: updatedWinner,
    loser: updatedLoser,
    match: newMatch
  };
};