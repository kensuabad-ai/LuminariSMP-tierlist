import { Player, Match, PointRules, Report, AuditLog } from '../types';

interface AppState {
  players: Player[];
  matches: Match[];
  pointRules: PointRules;
  reports: Report[];
  auditLogs: AuditLog[];
}

const STORAGE_KEY = 'luminari_smp_state';

export const storage = {
  save: (state: AppState) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (error) {
      console.error('Failed to save state:', error);
    }
  },
  
  load: (): AppState | null => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
      return null;
    } catch (error) {
      console.error('Failed to load state:', error);
      return null;
    }
  },
  
  clear: () => {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch (error) {
      console.error('Failed to clear state:', error);
    }
  }
};